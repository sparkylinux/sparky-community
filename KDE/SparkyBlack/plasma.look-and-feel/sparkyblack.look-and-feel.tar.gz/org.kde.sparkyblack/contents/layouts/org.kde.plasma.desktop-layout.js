var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
                {
                    "config": {
                    },
                    "geometry.height": 12,
                    "geometry.width": 14,
                    "geometry.x": 48,
                    "geometry.y": 12,
                    "plugin": "org.kde.plasma.systemmonitor.diskusage",
                    "title": "Uso do espaço do disco rígido"
                },
                {
                    "config": {
                    },
                    "geometry.height": 12,
                    "geometry.width": 14,
                    "geometry.x": 48,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.systemmonitor.memory",
                    "title": "Status da memória"
                },
                {
                    "config": {
                    },
                    "geometry.height": 12,
                    "geometry.width": 12,
                    "geometry.x": 36,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.weather",
                    "title": "Previsão do tempo"
                },
                {
                    "config": {
                        "/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        },
                        "/General": {
                            "sources": "disk%2Fsda_(8%3A0)%2FRate%2Fwblk,disk%2Fsdb_(8%3A16)%2FRate%2Fwblk"
                        }
                    },
                    "geometry.height": 12,
                    "geometry.width": 14,
                    "geometry.x": 61,
                    "geometry.y": 12,
                    "plugin": "org.kde.plasma.systemmonitor.diskactivity",
                    "title": "Monitor de E/S do disco rígido"
                },
                {
                    "config": {
                    },
                    "geometry.height": 12,
                    "geometry.width": 14,
                    "geometry.x": 61,
                    "geometry.y": 24,
                    "plugin": "org.kde.plasma.systemmonitor.net",
                    "title": "Monitor da rede"
                },
                {
                    "config": {
                    },
                    "geometry.height": 12,
                    "geometry.width": 14,
                    "geometry.x": 61,
                    "geometry.y": 0,
                    "plugin": "org.kde.plasma.systemmonitor.cpu",
                    "title": "Monitor de carga da CPU"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.slideshow"
                },
                "/ConfigDialog": {
                    "DialogHeight": "540",
                    "DialogWidth": "720"
                },
                "/Configuration": {
                    "PreloadWeight": "2"
                },
                "/General": {
                    "arrangement": "1",
                    "iconSize": "3",
                    "toolTips": "true"
                },
                "/Wallpaper/org.kde.image/General": {
                    "height": "768",
                    "width": "1024"
                },
                "/Wallpaper/org.kde.slideshow/General": {
                    "FillMode": "2",
                    "SlideInterval": "180",
                    "SlidePaths": "/usr/share/wallpapers"
                }
            },
            "wallpaperPlugin": "org.kde.slideshow"
        }
    ],
    "panels": [
        {
            "alignment": "left",
            "applets": [
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "PreloadWeight": "100"
                        },
                        "/Configuration/General": {
                            "favorites": "debian-installer-launcher.desktop,sparky-aptus-upgrade.desktop,systemsettings.desktop,sparky-aptus.desktop,org.kde.dolphin.desktop,firefox-esr.desktop,google-chrome.desktop,org.kde.konsole.desktop,putty.desktop,org.kde.knotes.desktop,libreoffice-writer.desktop,libreoffice-calc.desktop,vlc.desktop,org.kde.kdenlive.desktop,audacity.desktop",
                            "favoritesPortedToKAstats": "true"
                        },
                        "/Configuration/Shortcuts": {
                            "global": "Alt+F1"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "PreloadWeight": "2"
                        }
                    },
                    "plugin": "org.kde.plasma.pager"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "PreloadWeight": "2"
                        },
                        "/Configuration/General": {
                            "launchers": "file:///usr/share/applications/org.kde.dolphin.desktop,file:///usr/share/applications/org.kde.kcalc.desktop,file:///usr/share/applications/vlc.desktop,file:///usr/share/applications/libreoffice-writer.desktop,file:///usr/share/applications/libreoffice-calc.desktop,file:///usr/share/applications/google-chrome.desktop,file:///usr/share/applications/firefox-esr.desktop"
                        }
                    },
                    "plugin": "org.kde.plasma.taskmanager"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "PreloadWeight": "7"
                        }
                    },
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/": {
                            "immutability": "1"
                        },
                        "/Configuration": {
                            "PreloadWeight": "2"
                        },
                        "/Configuration/Appearance": {
                            "boldText": "true",
                            "selectedTimeZones": "America/Sao_Paulo,Local",
                            "showDate": "true",
                            "use24hFormat": "2"
                        },
                        "/Configuration/ConfigDialog": {
                            "DialogHeight": "540",
                            "DialogWidth": "720"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/Configuration": {
                    "PreloadWeight": "2"
                }
            },
            "height": 1.6666666666666667,
            "hiding": "normal",
            "location": "bottom",
            "maximumLength": 75.55555555555556,
            "minimumLength": 75.55555555555556,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
