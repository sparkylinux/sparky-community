WALLPAPER=/opt/artwork/sparky-grub.png
COLOR_NORMAL=white/black
COLOR_HIGHLIGHT=black/white
